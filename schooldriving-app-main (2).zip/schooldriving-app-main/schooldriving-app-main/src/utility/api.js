const config = {
  // api: 'http://localhost:4040/api/'
  api: 'https://mini-project-v1.herokuapp.com/api/'
};

export default config;
